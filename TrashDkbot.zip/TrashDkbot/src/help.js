const help = (prefix) => {
	return `Mini akira supreme(BOT)comandos:

🌊🐚🌕Comando : *${prefix}sticker* ou *${prefix}stiker*🌻✨🌞
desc : converter imagem / gif / vídeo em adesivo
uso : responder imagem / gif / vídeo ou enviar imagem / gif / vídeo com legenda\n🌊🌞✨

🌞✨🌊comando : *${prefix}sticker nobg* ou *${prefix}stiker nobg*🌊🌕🌻
desc : converter imagem em adesivo removendo o fundo
uso : responder imagem ou enviar imagem com legenda\n🌊🐚🌙✨

🌞✨🌊comando : *${prefix}toimg*
desc : converter sticker para imagem
uso : cite um sticker\n🌻🌙🐚🌞

🌾🌞🌊comando : *${prefix}tsticker* ou *${prefix}tstiker*
desc : converte texto em sticker
uso : *${prefix}tsticker Texto aqui*\n🌞🌊✨

🌾🌞🌊Comando : *${prefix}dono*🌾🌞🌊
🌾🌞🌊Desc : mostra o meu dono 😎🤙🌾🌞🌊

🌙✨> *Comandos de meme* <🌕🌞
comando : *${prefix}meme*
desc : Meme aleatório [Inglês]
uso : apenas envie o comando\n✨🌞

🌙✨Comando : *${prefix}porno*😎🤙🌾🌞🌊
🌾🌞🌊 Desc: 😏😏😏😏

🌊✨comando : *${prefix}memeindo*
desc : memes aleatórios [indonesio]
uso : apenas envie o comando\n🌊🐚

🌞🌊✨> *Outros comandos* <
comando : *${prefix}gtts*
desc : converte texto em áudio
uso : *${prefix}gtts [cc] [text]*\nexample : *${prefix}gtts pt iae mano*\n🐚🌊✨

🌾🌞🌊Comando : *${prefix}metaldark*😎🤙🌾🌞🌊
🌾🌞🌊desc : cria um textin 😎🤙

🌻🌾comando : *${prefix}loli*
desc : imagens de lolis aleatórias
uso : apenas envie o comando\n🪐🌕✨🌞

🌻🌾✨comando : *${prefix}nsfwloli*
desc : fotos de loli nfsw aleatórias
uso : apenas envie o comando\n🌻🌾✨

🌞🌕🌻🌾✨comando : *${prefix}url2img*
desc : pega prints de sites
uso : *${prefix}url2img [tipe] [url]*\n✨🌾

🌊🐚🪐comando : *${prefix}simi*
desc : suas mensagens serao respondidas pelo simi
uso : *${prefix}simi (sua mensagem)*\n🌞🌊

✨🌾🌞🌊comando : *${prefix}ocr*
desc : transforma o texto em pintura
uso : mande imagem,ou marque imagem com legenda\n🌾✨🌊🌞

🌊🌞🌾comando : *${prefix}wait*
desc : procurar o anime com uma imagem [ que anime é este ]
uso : responder imagem ou enviar imagem com legenda\n🌻✨🌞🌊

🌻🌾🌊comando : *${prefix}setprefix*
desc : recoloca o prefix
uso : *${prefix}setprefix [text|optional]*\n exemplo : *${prefix}setprefix ?*
note : Esse comando só pode ser usado pelo dono do bot 😎🤙\n🌊🌾✨🌞

🌞🌊✨> *Comandos de grupo* <
comando : *${prefix}add*
desc : Adiciona um membro ao grupo
uso : *${prefix}add 55849xxxxx*\n
note : só pode ser usado quando o bot se torna admin, e quem envia também é admin!\n✨🌞🌊

🌊🌞🌾comando : *${prefix}kick*
desc : expulsa membros do grupo
uso : *${prefix}kick @marcarmembro*\n
note : só pode ser usado quando o bot se torna admin, e quem envia o comando é admin!\n🌾🌻🌞🌊

✨🌞🌊comando : *${prefix}promote*
desc : faz um membro comum se tornar adm😎🤙
uso : *${prefix}promote @marcarmembro*\n
note : só pode ser usado quando o bot se torna admin, e quem envia o comando é admin!\n✨🌊🌾🌻

🪐🐚🌊comando : *${prefix}demote*
desc : faz um adm virar membro comum 😔🤙
uso : *${prefix}demote @marcarmembro*\n
note : só pode ser usado quando o bot se torna admin, e quem envia o comando é admin!\n✨🌞🌊

🌊🐚🌕comando : ${prefix}grupoabrir🌊🐚🌕
🌊🐚🌕Desc:abre o seu grupo se você e o bot forem adms🌊🐚🌕

🌊🐚🌕Comando : ${prefix}grupofechar🌊🐚🌕
🌊🐚🌕Desc : fecha o seu grupo se você e o bot forem adms🌊🐚🌕

🌊🌞✨comando : *${prefix}linkgroup*
desc : envia o link do grupo
uso : apenas envie o comando
note : só pode ser usado quando o bot se torna admin, e quem envia o comando é admin!\n🌊🌞🌻✨

🐚🌊✨🌞comando : *${prefix}leave*
desc : faz o bot sair do grupo
uso : apenas envie o comando
note : so pode ser usado por admins ou o dono do bot\n🌊✨🌞🌕

🌙🪐🌾✨comando : *${prefix}marcar*
desc : marca todos os membros e admins
uso : apenas envie o comando
note : Este comando so pode ser usado se você for admin\n✨🌊🌞🪐

🌊✨🪐comando : *${prefix}simih*
desc : ativa o modo simih
uso : *${prefix}simih 1* pra ativar o modo, e *${prefix}simih 0* pra desativar o modo simih
note : Este comando so pode ser usado se você for admin do grupo\n🌾🌞🪐🌊✨

          >Comandos novos<😎🤙🌾🌞🌊

🌾🌞🌊Comando : *${prefix}bomdia

🌾🌞🌊Comando : *${prefix}boatarde

🌾🌞🌊Comando : *${prefix}boa noite

🌊🐚🌕comando : *${prefix}destrava
🌊🐚🌕Desc : envia uma destrava pra destravar você ou o grupo

🐚🌕Comando : ${prefix}ytmp4🌊🐚🌕
Desc : pega um vídeo do YouTube e manda pra você
Uso : mande ${prefix}ytmp4 e o link do vídeo do youtube

🐚🌕Comando : ${prefix}setppbot🌊🐚🌕
🌊🐚🌕Desc : muda a foto de perfil do bot (apenas o dono pode usar)

🐚🌕Comando : ${prefix}blocklist🌊🐚🌕
🌊🐚🌕Desc : mostra todos os contatos bloqueados do bot🌊🐚🌕

🐚🌕Comando : ${prefix}wame🌊🐚🌕
🌊🐚🌕Desc : faz um comando WA.me com o seu número
🌊🐚🌕Uso : apenas mande o comando

🌊🐚🌕Comando : ${prefix}timer🌊🐚🌕
🌊🐚🌕Desc : faz uma contagem em segundos minutos ou horas
🌊🐚🌕uso : envie por exemplo ${prefix}timer 2 segundos, {prefix}timer 2 minutos ou {prefix}timer 2 horas🌊🐚🌕

🌊🐚🌕comando : ${prefix}image🌊🐚🌕
🌊🐚🌕Desc : procura uma imagem no Pinterest de acordo com o que você escrever
🌊🐚🌕uso : envie ${prefix}image cachorro🌊🐚🌕

🌊🐚🌕comando : ${prefix}anime🌊🐚🌕
🌊🐚🌕Desc : manda uma imagem aleatória de anime🌊🐚🌕

🌊🐚🌕Comando : ${prefix}menuadmin🌊🐚🌕
🌊🐚🌕Desc : mostra os comandos pra adms de grupos

🌊🐚🌕Comando : ${prefix}thalesarrombado🌊🐚🌕
🌊🐚🌕Desc : mostra o arrombado que derrubou o bot ._.(Zuera Thales)

🌊🐚🌕Comando : ${prefix}supporter🌊🐚🌕
🌊🐚🌕Desc : mostra os carinhas q protegem o bot

🔥🔥Recém atualizado🔥🔥

🔥Comando : ${prefix}apkpremium🔥
🔥Desc : mostra uma lista de apps Premium :0

🌊🐚🌕DIGITE ${prefix}updates PRA VER AS ATUALIZAÇÕES DO BOT MAIS RECENTES


❌❌❌❌+18❌❌❌❌

🌊🐚🌕comando : ${prefix}pack+18
🌊🐚🌕Desc : já deu pra entender


😎Contate meu dono Mini akira supreme caso tenha alguma dúvida: wa.me/5521965548665

'ঔৣ☬✞Mini akira supreme✞☬ঔৣ:🌞🌊✨🌙Wa.me/5521965548665🌞🌊✨🌙
~𝐶𝑜𝑛𝑡𝑎𝑡𝑜 𝑑𝑎 𝑐𝑟𝑒𝑚𝑜𝑠𝑎, 𝑒𝑙𝑎 𝑎𝑗𝑢𝑑𝑜𝑢 𝑛𝑜 𝑚𝑒𝑛𝑢.~

`

}

exports.help = help
