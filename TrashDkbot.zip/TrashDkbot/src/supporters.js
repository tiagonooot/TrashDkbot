const supporters = () => {
    return `

❌✞ ✞❌
𝑁𝐾 𝑊𝐴𝑅 𝛩𝐹 𝑃𝜟𝐼𝑵𝜩𝑳



Se vc quer se tornar um supporters,entre em contato com o meu dono,


Aviso- pra se tornar supporters vc precisará rajar travas em pessoas q tentarem derrubar o bot.
`

}

exports.supporters = supporters
