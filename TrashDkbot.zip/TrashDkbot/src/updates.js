const updates = (prefix, pushname) => {
 return `
Novos comandos atualizados pelo meu dono 
novos comandos :  

${prefix}Ytmp4

${prefix}Setppbot

${prefix}Blocklist 

${prefix}wame

${prefix}image

${prefix}loli(refeito funcionando)

${prefix}grupo fechar

${prefix}grupo abrir

09/02/2021 Update:Mini akira supreme

${prefix}pack+18

${prefix}destrava

15/02/2021 Update:Mini akira supreme

${prefix}apkpremium




digite ${prefix}help pra ver os comandos com mais detalhes
 `


}

exports.updates = updates
