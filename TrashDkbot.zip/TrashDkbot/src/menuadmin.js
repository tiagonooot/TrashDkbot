const menuadmin = (prefix, pushname) => {
 return `oiin aqui e o menu dos admins
 _obs para o bot executar esses comandos e nescessario dar adm para o bot ASS:Mini akira supreme_
 
 ◪ *COMANDO DOS ADMINS*
 │
 ├─ ❏ ${prefix}grupo abrir
 ├─ ❏ ${prefix}grupo fechar
 ├─ ❏ ${prefix}promote
 ├─ ❏ ${prefix}demote
 ├─ ❏ ${prefix}marcar
 ├─ ❏ ${prefix}marcar1
 ├─ ❏ ${prefix}marcar2
 ├─ ❏ ${prefix}marcar3
 ├─ ❏ ${prefix}add
 ├─ ❏ ${prefix}kick
 ├─ ❏ ${prefix}listadmins
 ├─ ❏ ${prefix}linkgroup
 ├─ ❏ ${prefix}leave
 ├─ ❏ ${prefix}welcome
 ├─ ❏ ${prefix}simih
 ├─ ❏ ${prefix}tmgc (apenas o meu dono pode usar)

 `


}

exports.menuadmin = menuadmin
